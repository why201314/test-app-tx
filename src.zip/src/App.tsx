import React from 'react';
import logo from './logo.svg';
import './css/App.css';
import MuiTest from './MuiTest';
import PrimarySearchAppBar from './component/MyMenu'
import AppRouter from './component/AppRouter';
import SignIn from './component/SignIn';
import StickyFooter from './component/StickyFooter';
import APIClient from './component/utils/APIClient';

function App() {
  return (
    <div className="App">
      <PrimarySearchAppBar />
      <MuiTest />
      <APIClient name="app" url="http://test.com"/>
      <StickyFooter />
    </div>
  );
}

export default App;
