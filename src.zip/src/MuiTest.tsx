import * as React from 'react';
import Button from '@mui/material/Button';

export default function MuiTest() {
    return (
        <div>
          <Button variant="contained">Hello World</Button>
        </div>
      );
}